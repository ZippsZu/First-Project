# include <iostream>
using namespace std;
int main()
{	
    char str[50];
    cout<<"Enter the String"<<endl;
    cin.getline(str,50);
	for(int i=0;str[i]!='\0';i++)
	{
		if(str[i]=='C')
		{
			i++;
			if(str[i]=='O')
			{
				i++;
				if(str[i]=='N')
				{
					i++;
					if(str[i]=='S')
					{
						i++;
						if(str[i]=='T'){
							i++;
							if(str[i]==' ')
							{
						cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
		}
		if(str[i]=='F')
		{
			i++;
			if(str[i]=='L')
			{
				i++;
				if(str[i]=='O')
				{
					i++;
					if(str[i]=='A')
					{
						i++;
						if(str[i]=='T'){
							i++;
							if(str[i]==' ')
							{
						cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
		}
		if(str[i]=='I')
    	{
    		i++;
              if(str[i]=='N')
    	{
    		i++;
               		if(str[i]=='T')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               		cout<<"Reserve Word"<<endl; 	i++;
				   }
		}
		} 		
	}
		if(str[i]=='B')
		{
			i++;
			if(str[i]=='R')
			{
				i++;
				if(str[i]=='E')
				{
					i++;
					if(str[i]=='A')
					{
						i++;
						if(str[i]=='K'){
							i++;
							if(str[i]==' ')
							{
								cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
		}
			if(str[i]=='C')
		{
			i++;
			if(str[i]=='O')
			{
				i++;
				if(str[i]=='N')
				{
					i++;
					if(str[i]=='T')
					{
						i++;
						if(str[i]=='I'){
							i++;
							
							if(str[i]=='N')
							{
								i++;
								if(str[i]=='U')
								{
									i++;
									if(str[i]=='E')
									{
										i++;
											     	if(str[i]==' ')
							                        {                           
								                 cout<<"Reserve Word"<<endl; i++;
					                      		}		
							}
								}
							}
						}
					}
				}
			}
		}
		if(str[i]=='E')
		{
			i++;
			if(str[i]=='L')
			{
				i++;
				if(str[i]=='S')
				{
					i++;
					if(str[i]=='E')
					{
						i++;
							if(str[i]==' ')
							{
								cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
	if(str[i]=='S')
		{
			i++;
			if(str[i]=='W')
			{
				i++;
				if(str[i]=='I')
				{
					i++;
					if(str[i]=='T')
					{
						i++;
						if(str[i]=='C'){
							i++;
							
							if(str[i]=='H')
							{
								i++;
											     	if(str[i]==' ')
							                        {                           
								               cout<<"Reserve Word"<<endl; i++;
					                      		}	
									}
								}
							
							}
						}
					}
				}
			if(str[i]=='V')
		{
			i++;
			if(str[i]=='O')
			{
				i++;
				if(str[i]=='I')
				{
					i++;
					if(str[i]=='D')
					{
						i++;
							if(str[i]==' ')
							{
						cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
			if(str[i]=='E')
		{
			i++;
			if(str[i]=='N')
			{
				i++;
				if(str[i]=='U')
				{
					i++;
					if(str[i]=='M')
					{
						i++;
							if(str[i]==' ')
							{
								cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
			if(str[i]=='T')
		{
			i++;
			if(str[i]=='Y')
			{
				i++;
				if(str[i]=='P')
				{
					i++;
					if(str[i]=='E')
					{
						i++;
						if(str[i]=='D'){
							i++;
							
							if(str[i]=='E')
							{
								i++;
								if(str[i]=='F')
								{
									i++;
											     	if(str[i]==' ')
							                        {                           
								               cout<<"Reserve Word"<<endl; i++;
					                      		}
									}
								}	
						}
					}
				}
			}
		}
	if(str[i]=='D')
    	{
    		i++;
              if(str[i]=='O')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Reserve Word"<<endl; 	i++;
				   }
		} 		
	}	  
		if(str[i]=='R')
		{
			i++;
			if(str[i]=='E')
			{
				i++;
				if(str[i]=='T')
				{
					i++;
					if(str[i]=='U')
					{
						i++;
						if(str[i]=='R'){
							i++;
							
							if(str[i]=='N')
							{
								i++;
											     	if(str[i]==' ')
							                        {                           
								                cout<<"Reserve Word"<<endl; i++;
					                      		}		
									}
								}
							
							}
						}
					}
				}  
		  if(str[i]=='U')
		{
			i++;
			if(str[i]=='N')
			{
				i++;
				if(str[i]=='I')
				{
					i++;
					if(str[i]=='O')
					{
						i++;
						if(str[i]=='N'){
							i++;
							if(str[i]==' ')
							{
								cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
		}
		  if(str[i]=='W')
		{
			i++;
			if(str[i]=='H')
			{
				i++;
				if(str[i]=='I')
				{
					i++;
					if(str[i]=='L')
					{
						i++;
						if(str[i]=='E'){
							i++;
							if(str[i]==' ')
							{
							cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
		}
			if(str[i]=='F')
    	{
    		i++;
              if(str[i]=='O')
    	{
    		i++;
               		if(str[i]=='R')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Reserve Word"<<endl;	i++;
				   }
		}
		} 		
	}
		if(str[i]=='C')
		{
			i++;
			if(str[i]=='A')
			{
				i++;
				if(str[i]=='S')
				{
					i++;
					if(str[i]=='E')
					{
						i++;
							if(str[i]==' ')
							{
							cout<<"Reserve Word"<<endl; i++;
							}
						}
					}
				}
			}
   	for(int i=0;str[i]!='\0';i++)
	 {
	 	if(str[i]=='/' && str[i+1]=='/')
	 	{ 	
		cout<<"single line comment"<<endl;
		 } 
	 }
	for(int i=0;str[i]!='\0';i++)
	 {
	 	if(str[i]=='/' && str[i+1]=='*')
	 	{ 	
	 	
	 	for(i=2;str[i]!='\0';i++)
	 	{
		 	if(str[i]=='*' && str[i+1]=='/')
			 {
			 cout<<"multiple line comment"<<endl;
				 }	 	
			}
	 }
}
   	for(int i=0;str[i]!='\0';i++)
	{
			if(str[i]=='<')
    	{
    		i++;
              if(str[i]=='>')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
	
	if(str[i]=='+')
    	{
    		i++;
              if(str[i]=='=')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
		if(str[i]=='-')
    	{
    		i++;
              if(str[i]=='=')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
			if(str[i]=='+')
    	{
    		i++;
              if(str[i]=='+')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
		
			if(str[i]=='-')
    	{
    		i++;
              if(str[i]=='-')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
		if(str[i]=='|')
    	{
    		i++;
              if(str[i]=='&')
    	{
    		i++;
    		
              if(str[i]==' ')
    	{
    		i++;
    		
              if(str[i]=='a')
    	{
    		i++;
    		
              if(str[i]=='s')
    	{
    		i++;
    		
              if(str[i]==' ')
    	{
    		i++;
    		
              if(str[i]=='X')
    	{
    		i++;
    		
              if(str[i]=='O')
    	{
    		i++;
    		
              if(str[i]=='R')
    	{
    		i++;
              
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
      }
       }
           } 
       }
           }
          }
            }
		if(str[i]=='&')
    	{
    		i++;
              if(str[i]=='|')
    	{
    		i++;
    		
              if(str[i]==' ')
    	{
    		i++;
    		
              if(str[i]=='a')
    	{
    		i++;
    		
              if(str[i]=='s')
    	{
    		i++;
    		
              if(str[i]==' ')
    	{
    		i++;
    		
              if(str[i]=='N')
    	{
    		i++;
    		
              if(str[i]=='O')
    	{
    		i++;
    		
              if(str[i]=='R')
    	{
    		i++;
              
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
}
   }  
   }
        }
      }
	   }   
	   }
			if(str[i]=='<')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
		if(str[i]=='>')
    	{
    		i++;
              if(str[i]=='>')
    	{
    		i++;
    		
              if(str[i]=='>')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Input"<<endl;	i++;
				   }
		} 		
	}
}
		if(str[i]=='<')
    	{
    		i++;
              if(str[i]=='<')
    	{
    		i++;
    		
              if(str[i]=='<')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Output"<<endl;	i++;
				   }
		} 		
	}
}	
			if(str[i]=='!')
    	{
    		i++;
              if(str[i]=='=')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
			if(str[i]==':')
    	{
    		i++;
              if(str[i]=='=')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
			if(str[i]=='=')
    	{
    		i++;
              if(str[i]=='=')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}
			if(str[i]=='+')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
		if(str[i]=='*')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
		if(str[i]=='/')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
		if(str[i]=='-')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
			if(str[i]=='>')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		}
			if(str[i]=='&')
    	{
    		i++;
              if(str[i]=='&')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }	
		} 		
	}
		if(str[i]=='|')
    	{
    		i++;
              if(str[i]=='|')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Operator"<<endl;	i++;
				   }
		} 		
	}		
	}
	for(int i=0;str[i]!='\0';i++)
	{
			if(str[i]=='[')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]==']')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]=='{')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]=='}')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]=='(')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]==')')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]=='"')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
		if(str[i]=='"')
    	{
    		i++;
               	if(str[i]==' ')
               	{
               	cout<<"Punctuation"<<endl;	i++;
				   }
		}
			i++;
	}
}
}
